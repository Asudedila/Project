#include "recipe.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QStandardPaths>

Recipe::Recipe() {}

QString Recipe::toString() const {
    return "Name: " + name + "\nIngredients:\n" + ingredients + "\n\nInstructions:\n " + instructions;
}

void Recipe::readFile(const QString& file_name) {
    QString desktop_path = QStandardPaths::writableLocation(QStandardPaths::DesktopLocation);
    QString file_path = desktop_path + "/food/"+ file_name;
    QFile file(file_path);

    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream stream(&file);
        if(stream.readLineInto(&firstLine)){
            if (stream.readLineInto(&name)) {

                if (stream.readLineInto(&ingredients)) {

                    while (!stream.atEnd()) {
                    QString line = stream.readLine();
                    instructions += line + '\n';
                    }
                }
            }
        }
        file.close();
    } else {
        qDebug() << file_name << "file cannot be found.";
    }
}
