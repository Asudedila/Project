#include "recipeselectiondialog.h"
#include "ui_recipeselectiondialog.h"
#include <recipe.h>
#include <ingredients.h>
#include <QStandardPaths>
#include <QListWidgetItem>
#include <QScreen>


RecipeSelectionDialog::RecipeSelectionDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::RecipeSelectionDialog)
{
    ui->setupUi(this);
    move(screen()->geometry().center() - frameGeometry().center());

    QPixmap pix("C:/Users/asust/Desktop/görsel.jpg");
    ui->label_2->setPixmap(pix.scaled(819,700,Qt::KeepAspectRatio));
}

RecipeSelectionDialog::~RecipeSelectionDialog()
{
    delete ui;
}

void RecipeSelectionDialog::setRecipeList(const QStringList &recipeNames)
{
    ui->listWidget->addItems(recipeNames);
}

void RecipeSelectionDialog::on_listWidget_itemSelectionChanged()
{
    QListWidgetItem *selectedItem = ui->listWidget->currentItem();

    qDebug()<<selectedItem->text();

    QString selectedRecipeName = selectedItem->text();
    emit recipeSelected(selectedRecipeName);

    Recipe recipe;
    recipe.readFile(selectedRecipeName + ".txt");
    ui->textEdit->setText(recipe.toString());
}
